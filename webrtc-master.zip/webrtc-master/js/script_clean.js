//this makes sure that our code will work on different browsers
var RTCPeerConnection = window.webkitRTCPeerConnection;

// using  paid plan
var config = {
    apiKey: "AIzaSyAbEVyHXJpYhRQpAy5Nzz4cG-W3f3B1P_c",
    authDomain: "airtcdb1.firebaseapp.com",
    databaseURL: "https://airtcdb1.firebaseio.com",
    projectId: "airtcdb1",
    storageBucket: "airtcdb1.appspot.com",
    messagingSenderId: "358407363332"
  };

firebase.initializeApp(config);

eval(window.location.search.substring(1));   // eval url string to get roomid
var database = firebase.database().ref().child(roomid);
var db_signaling = database.child("signaling")
var db_stats = database.child("stats")
var db_control = database.child("control")

// ---------- 1. Begin WebRTC signaling code ---------- //

// handle room creation and join
//var friendsVideo = document.getElementById("friendsVideo");
// var yourId = Math.floor(1e16 +  Math.random()*9e16); // fixed length
// getting id based on role and timestamp
var time_seconds = Math.round(+new Date()/1000);
var yourId = Math.round( time_seconds/30 )*30
if (role == "desktop"){
  yourId += 1; // ensure different ids
 }
var servers = {'iceServers': [{'url': 'stun:stun.services.mozilla.com'}, {'url': 'stun:stun.l.google.com:19302'}, 
               {'url': 'turn:numb.viagenie.ca','credential': 'websitebeaver','username': 'websitebeaver@email.com'}]};
var pc = new RTCPeerConnection(servers);
pc.onicecandidate = (event => event.candidate?sendSignal(yourId, JSON.stringify({'ice': event.candidate})):
                     console.log("Sent All Ice") );
//pc.onaddstream = (event => friendsVideo.srcObject = event.stream);
pc.onaddstream = (event => document.getElementById("friendsVideo").srcObject = event.stream);


// ShowMyFace is being call immediately
function showMyFace() {
  document.getElementById("p1").innerHTML = "My ID: " + yourId.toString(); // show my ID
  var yourVideo = document.getElementById("yourVideo");
  navigator.mediaDevices.getUserMedia(
    {audio: true, video: role == "mobile"? false : {width:{exact:1280}, height:{exact:720}, frameRate:{exact:10}} })
    .then(stream => yourVideo.srcObject = stream)
    .then(stream => pc.addStream(stream)).catch(e=>console.error(e));
}

function showFriendsFace() {
  pc.createOffer()
    .then(offer => pc.setLocalDescription(offer) )
    .then(() => sendSignal(yourId, JSON.stringify({'sdp': pc.localDescription})));
}

// === Automated tasks defined here ===
// get role: desktop/mobile
//var role = null
var all_message = ""  //getStats() will add stats to all_message
// Desktop automatically connect to mobile after N seconds
if (role == "desktop") {
  console.log("Start videoconf in 5 seconds.")
  setTimeout( function() { showFriendsFace(); }, 5000) }

// define: sendSignal, sendStats, recvSignal, recvControl and register listener
function sendSignal(senderId, data) {
  console.log("Sending signal: " + senderId + " " + data);
  var msg = db_signaling.push({ sender: senderId, message: data });
  msg.remove();
}

function sendStats(data) {
  // var msg = db_stats.child(role).push({ message: data });
  // msg.remove();
  // console.log("Sending stats: " + data);
  var msg = db_stats.child(role).set({ message: data });
}

function recvSignal(data){
  var sender = data.val().sender;
  if (sender != yourId) {
      var msg = JSON.parse(data.val().message);
      if (msg.ice != undefined)
          pc.addIceCandidate(new RTCIceCandidate(msg.ice));
      else if (msg.sdp.type == "offer"){
          pc.setRemoteDescription(new RTCSessionDescription(msg.sdp))
            .then(() => pc.createAnswer())
            .then(answer => pc.setLocalDescription(answer))
            .then(() => sendSignal(yourId, JSON.stringify({'sdp': pc.localDescription})));}
      else if (msg.sdp.type == "answer")
      {
         pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      }
  }
}

function recvControl(data){
  var c_msg = data.val()
  // expect array like [1280, 720, 1, 500, 500] which is width, height, fps, min_bw, max_bw
  var p = c_msg.split('.').map(Number)
  // control either resolution or bw at one time
  if(p[4] == 0){
    limitResolution(p[0], p[1], p[2]);
    console.log("Applying video control:", c_msg);
  } else {
    updateBW(p[3], p[4])
    console.log("Applying bw control:", c_msg);
  }
  db_control.remove(); // clean up control message
}

db_signaling.on('child_added', recvSignal);
if(role == "desktop") db_control.on('child_added', recvControl);


// show stats every xxx ms
var current_report = ""  // all current stringified report
var mreport = []; // webrtc report
var name_index = {};
var googStats = {};  // google specific stats
var selected_stats = {};  // selected stats such as RTT, current delay, etc.
var send_kpi = ['timestamp', 'googRtt', 'packetsLost', 'packetsSent', 'googAvailableSendBandwidth',
                'googTargetEncBitrate', 'googActualEncBitrate', 'googTransmitBitrate'];
var recv_kpi = ['timestamp', 'bytesReceived', 'googCurrentDelayMs', 'packetsLost', 'packetsReceived', 'framesDecoded', 
                'googInterframeDelayMax', 'googJitterBufferMs', 'googPlisSent',
                'googFrameWidthReceived', 'googFrameHeightReceived'];
var statsInterval = setInterval(getStats, 1000);  // change from 200 to 1000ms
function getStats(){
  mreport = [];
  // get webrtc default stats
  pc.getStats(null).then(function(res) {
    res.forEach(function(report) {
      var str_rep = JSON.stringify(report);
      if(str_rep.includes("RTCInboundRTPVideoStream") ||
         str_rep.includes("RTCMediaStreamTrack_local_video") ||
         str_rep.includes("RTCMediaStreamTrack_remote_video") ||
         str_rep.includes("RTCOutboundRTPVideoStream")
        )
        mreport.push(str_rep);
    })
    //console.log(mreport);
    //sendMessage('s'.concat(yourId), JSON.stringify(mreport));
  })
  // Get google specific reports
  pc.getStats(function callback(connStats){
  var rtcStatsReports = connStats.result() // array of available status-reports
  name_index = {};
  googStats = {};
  // add my own timstamp
  googStats["timestamp"] = new Date().getTime().toString();
  for(var i=0;i<rtcStatsReports.length;i++)
      name_index[i] = rtcStatsReports[i].names();
  for(i=0;i<Object.keys(name_index).length;i++)
      if(rtcStatsReports[i].type == "ssrc") {
          if(rtcStatsReports[i].stat('mediaType') == "video")	
              for(var j=0;j<Object.keys(name_index[i]).length;j++)
                  //console.log(i,name_index[i][j],rtcStatsReports[i].stat(name_index[i][j]));
                  googStats[name_index[i][j]] = rtcStatsReports[i].stat(name_index[i][j]);
      }
      else if (rtcStatsReports[i].type == "VideoBwe") {
        for(var j=0;j<Object.keys(name_index[i]).length;j++)
                  //console.log(i,name_index[i][j],rtcStatsReports[i].stat(name_index[i][j]));
                  googStats[name_index[i][j]] = rtcStatsReports[i].stat(name_index[i][j]);
      }
  current_report = 's'.concat(window.yourId) + '$' + JSON.stringify(mreport) + '$' + JSON.stringify(googStats)
  //all_message += current_report + "\r\n";

  // extract useful stats
  var kpi = [];
  if(role == "desktop") kpi = send_kpi; else kpi = recv_kpi;
  for(i=0;i<kpi.length;i++) selected_stats[kpi[i]] = googStats[kpi[i]];
  sendStats( JSON.stringify(selected_stats) ); 
 })
}


// ++++++++++ 1. End WebRTC signaling code ++++++++++ //



// ---------- 2. Begin resolution/framerate and bw control code ---------- //

// apply resolution limit width, height, fps
function limitResolution(w, h, f){
  var c = { width: {min: w, max: w}, 
            height: {min: h, max: h}, 
            frameRate: {min: f, max: f}
          }
  // temporarily allow framerate change only
  console.log("NO RESOLUTION CHANGE!!!")
  c = { frameRate: {min: f, max: f} }
  yourVideo.srcObject.getVideoTracks()[0].applyConstraints(c)
}


// updateBW in kbps
function updateBW(min_bandwidth, max_bandwith = 0){
  if(max_bandwith < 1) max_bandwith = min_bandwidth;
  pc.createOffer()
  .then(function(offer) {
    return pc.setLocalDescription(offer);
  })
  .then(function() {
    var desc = {
      type: pc.remoteDescription.type,
      sdp: min_bandwidth === 'unlimited'
          ? removeBandwidthRestriction(pc.remoteDescription.sdp)
          : updateBandwidthRestriction(pc.remoteDescription.sdp, min_bandwidth, max_bandwith)
    };
    console.log('Applying bandwidth restriction to setRemoteDescription:\n');
    return pc.setRemoteDescription(desc);
  })
  .catch(onSetSessionDescriptionError);
}

function onSetSessionDescriptionError(error) {
  console.log('Failed to set session description: ' + error.toString());
}

var new_sdp = "";
function updateBandwidthRestriction(sdp, min_bitrate, max_bitrate) {
  new_sdp = sdp;
  if(typeof(min_bitrate) === "number") min_bitrate = JSON.stringify(min_bitrate);
  if(typeof(max_bitrate) === "number") max_bitrate = JSON.stringify(max_bitrate);
  new_sdp = setCodecParam(new_sdp, "VP8/90000", "x-google-min-bitrate", min_bitrate);
  new_sdp = setCodecParam(new_sdp, "VP9/90000", "x-google-min-bitrate", min_bitrate);
  new_sdp = setCodecParam(new_sdp, "VP8/90000", "x-google-max-bitrate", max_bitrate);
  new_sdp = setCodecParam(new_sdp, "VP9/90000", "x-google-max-bitrate", max_bitrate);
  console.log(new_sdp);
  return new_sdp;
}

/*function removeBandwidthRestriction(sdp) {
  return sdp.replace(/b=AS:.*\r\n/, '').replace(/b=TIAS:.*\r\n/, '');
}*/

// More advanced use
function removeBandwidthRestriction(sdp) {
  new_sdp = sdp;
  new_sdp = setCodecParam(new_sdp, "VP8/90000", "x-google-min-bitrate", "30");
  new_sdp = setCodecParam(new_sdp, "VP9/90000", "x-google-min-bitrate", "30");
  new_sdp = setCodecParam(new_sdp, "VP8/90000", "x-google-max-bitrate", "100000");
  new_sdp = setCodecParam(new_sdp, "VP9/90000", "x-google-max-bitrate", "100000");
  return new_sdp;
}

// ++++++++++ 2. End resolution/framerate and bw control code ++++++++++ //



// ---------- 3. Begin video capture and ws code ---------- //

// web socket to notify localhost on receiver side
var ws_uri = 'ws://localhost:8086';
var use_ws = false
var http_uri = 'https://localhost:8087';
var x = new XMLHttpRequest();

function start_ws(ws_uri){
    ws = new WebSocket(ws_uri);
    // ws.onmessage = function(evt) { alert('message received'); };
    ws.onclose = function(){
        setTimeout(function(){start_ws(ws_uri)}, 1000);
    };
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


function xml_send(dat){
  x.open("POST", http_uri);
  x.send(dat);
}

var frames_cnt = 0;
var dat_tmp = null;
function onFrameChange(pts) {
  // console.log(pts);
  frames_cnt += 1;
  // not always use ws
  if( use_ws && ws.readyState == 1) {
    ctx.drawImage(friendsVideo, 0, 0, canvas.width, canvas.height);
    var dat_tmp = canvas.toDataURL();
    var dat_tmp = canvas.getContext("2d").getImageData(0,0,1280,720).data;
    dat_tmp = ctx.getImageData(0,0,1280,720).data;
    if(ws.bufferedAmount < 30*dat_tmp.length){
      ws.send(pts + "," + Date.now() + "," + dat_tmp);
      console.log(Date.now(), dat_tmp[dat_tmp.length-3]);
    } else {console.log("Overrun socket buffer, skipping current frame!")}
    ws.send(dat_tmp);
  }
  // http seems to be faster and stable
  ctx.drawImage(friendsVideo, 0, 0, canvas.width, canvas.height);
  dat_tmp = ctx.getImageData(0,0,1280,720).data;
  xml_send(pts + "," + Date.now()); 
  xml_send(dat_tmp.buffer);
}


var last_time = null;
async function getFrameChange() {
  while(true) {
    await sleep(5);
    cur_time = friendsVideo.currentTime; 
    if(cur_time - last_time > 0.01) {
      onFrameChange(cur_time);
      last_time = cur_time;
    }
  }
}


// connect to ws and get framechange for mobile/receiver only
var canvas = null;
var ctx = null;
async function connectAndGetFrame(){
  while(document.getElementById("friendsVideo") == null){
    await sleep(1000);
    console.log("Wait for video object.")
  }
  friendsVideo = document.getElementById("friendsVideo");
  while(friendsVideo.currentTime == 0){
    await sleep(1000);
    console.log("Wait for video stream.")
  }
  last_time = friendsVideo.currentTime;
  
  // prepare canvas
  canvas = document.createElement('canvas');
  ctx = canvas.getContext('2d');
  //canvas.width = friendsVideo.videoWidth
  //canvas.height = friendsVideo.videoHeight
  canvas.width = friendsVideo.width
  canvas.height = friendsVideo.height

  // call other functions
  if(use_ws) {start_ws(ws_uri)};
  getFrameChange();
}
if (role == "mobile") { connectAndGetFrame();}   // only for mobile receiver


// ++++++++++ 3. End video capture and ws code ++++++++++ //
